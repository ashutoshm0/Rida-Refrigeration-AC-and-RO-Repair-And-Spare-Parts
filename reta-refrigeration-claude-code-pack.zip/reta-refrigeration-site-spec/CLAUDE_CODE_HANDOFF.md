# Claude Code Execution Brief — Reta Refrigeration

You are building a production-ready local-business website for:

**Reta Refrigeration — AC & RO Repair, Sales, Rental & Spare Parts**

Location: Sector 149, Greater Noida, India.

Read all files under `/docs`, `/config`, `/content`, `/data`, and `/assets` before making architectural decisions.

## Primary goal

Maximize qualified local enquiries generated from:

- Meta Ads
- Instagram
- Google Search
- Google Maps / Business Profile
- Direct / referral traffic

Primary action:
**WhatsApp**

Secondary:
**Call**

Other:
- Callback
- Book service
- Product enquiry
- Spare-part enquiry
- Get directions

## Product principles

1. Mobile-first.
2. Local Indian audience first.
3. Fast time-to-information.
4. WhatsApp is the dominant CTA.
5. Phone is always one tap away on mobile.
6. Contextual CTA copy, not generic "Contact Us" everywhere.
7. Real business information only.
8. No fake reviews.
9. No invented pricing.
10. No unsupported service-area or guarantee claims.
11. No unnecessary account creation.
12. No full e-commerce in v1.
13. Design like a trustworthy local shop, not a multinational corporation.
14. Real photos are preferred over stock imagery.
15. Every ad should have a relevant landing page.

## Build order

### Step 1 — Bootstrap
- Create Next.js + TypeScript app.
- Configure Tailwind.
- Configure linting/formatting.
- Establish environment variable pattern.
- Create component and route structure from `docs/ARCHITECTURE.md`.

### Step 2 — Data/content layer
- Create typed business config.
- Create typed services/products/spare-parts/content models.
- Keep business-specific values outside reusable UI components.
- Use placeholder values where the owner has not supplied data.

### Step 3 — Design system
Implement:
- typography scale
- spacing
- cards
- buttons
- badges
- forms
- section headers
- CTA variants
- responsive breakpoints
- sticky mobile CTA

See `docs/DESIGN_SYSTEM.md`.

### Step 4 — Core pages
Build in this order:
1. Homepage
2. AC Repair
3. RO Repair
4. AC Rental
5. AC Sale
6. Spare Parts
7. Product detail / enquiry state
8. Contact / Location
9. Book Service
10. Reviews / Testimonials
11. 404

See `docs/ROUTES.md`.

### Step 5 — Conversion system
Implement:
- WhatsApp click-to-chat utility
- contextual prefilled messages
- `tel:` links
- callback form
- booking form
- spare-part photo enquiry CTA
- directions CTA
- sticky mobile CTA

### Step 6 — Tracking
Implement event abstractions before final UI wiring:
- `whatsapp_click`
- `phone_click`
- `callback_submit`
- `booking_submit`
- `product_enquiry`
- `spare_part_enquiry`
- `rental_enquiry`
- `get_directions`

See `docs/META_TRACKING.md`.

### Step 7 — Local SEO
Implement:
- title/description system
- canonical URLs
- sitemap
- robots
- Open Graph
- LocalBusiness/Organization structured data
- NAP consistency
- location/service-area content
- Search Console readiness

See `docs/SEO_LOCAL.md`.

### Step 8 — QA
Run the complete checklist in `docs/QA_CHECKLIST.md`.

## Critical content safety

Never create:
- fake customer names
- fake Google reviews
- fake star ratings
- fake "10+ years" claims
- fake customer counts
- fake guarantees
- fake discounts
- fake "24/7" claims
- fake "same-day" claims
- fake service areas
- fake product brands
- fake prices

Use `[OWNER_TO_PROVIDE]` or equivalent placeholders until real data is supplied.

## UX requirements

The visitor should know within seconds:
- what the business does
- where it is
- whether it handles their problem
- how to contact it

The top of mobile pages should always expose:
- call
- WhatsApp
- relevant intent

## Landing-page rule

Meta Ads must not all land on `/`.

Map ad intent to a matching page:
- AC repair ad → `/ac-repair-greater-noida`
- RO repair ad → `/ro-repair-greater-noida`
- AC rental ad → `/ac-rental-greater-noida`
- spare-parts ad → `/spare-parts`
- AC sale ad → `/ac-sale-greater-noida`

Locality wording must be based on actual approved service coverage.

## Definition of done

A build is complete only when:
- all routes work
- all CTA links work
- WhatsApp messages are contextual
- phone links are correct
- forms work
- maps/directions work
- mobile sticky CTA works
- no placeholder content remains except intentionally documented owner inputs
- analytics events fire
- metadata exists
- structured data validates
- no major console errors exist
- mobile Lighthouse/Core Web Vitals are treated as a performance target
- production deployment works on HTTPS
