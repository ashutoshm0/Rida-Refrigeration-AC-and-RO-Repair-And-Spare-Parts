# Reta Refrigeration Website — Claude Code Handoff Pack

This repository/spec pack is the implementation source of truth for building the Reta Refrigeration website.

## Business

**Brand:** Reta Refrigeration  
**Working descriptor:** AC & RO Repair • Sales • Rental • Spare Parts  
**Primary location:** Sector 149, Greater Noida, India  
**Primary audience:** Local customers within the business's practical service/sales radius (roughly 50–70 km market opportunity, but actual service coverage must be confirmed by the owner).  
**Primary conversion:** WhatsApp enquiry  
**Secondary conversion:** Phone call  
**Other conversions:** Callback request, service booking, product enquiry, spare-parts enquiry, directions/store visit.

> IMPORTANT: Do not invent phone numbers, exact address, timings, service areas, reviews, prices, brand partnerships, years of experience, guarantees, or service promises. Replace placeholders only with owner-approved information.

## Project philosophy

This is a **local Indian lead-generation + digital shop-counter website**, not a corporate brochure and not a full e-commerce platform in v1.

Core funnel:

Meta / Instagram Ad
→ Intent-specific landing page
→ Trust + relevant information
→ WhatsApp / Call
→ Lead
→ Shop / Technician
→ Service / Sale / Rental

## Primary implementation docs

1. `docs/PROJECT_SPEC.md` — complete product requirements
2. `docs/ARCHITECTURE.md` — application architecture and folder structure
3. `docs/DESIGN_SYSTEM.md` — visual and UX system
4. `docs/ROUTES.md` — route map and page requirements
5. `docs/CONTENT_MODEL.md` — content strategy and rules
6. `docs/DATA_SCHEMA.md` — database/content schema
7. `docs/INTEGRATIONS.md` — WhatsApp, phone, Maps, analytics, forms
8. `docs/META_TRACKING.md` — Meta Ads tracking/events/UTM plan
9. `docs/SEO_LOCAL.md` — local SEO and Google Business Profile alignment
10. `docs/ADMIN.md` — admin/CMS requirements
11. `docs/QA_CHECKLIST.md` — launch and regression checklist
12. `CLAUDE_CODE_HANDOFF.md` — execution order for Claude Code

## Technology recommendation

- Next.js
- TypeScript
- Tailwind CSS
- Supabase (or equivalent managed database/auth)
- Vercel (or equivalent)
- Responsive/mobile-first UI
- Server/client separation where appropriate
- Structured data for local business
- Meta Pixel / Conversions tracking
- Google Analytics 4
- Google Search Console
- WhatsApp click-to-chat
- `tel:` phone links
- Google Maps / directions links

## v1 scope

- High-conversion homepage
- Service pages
- AC sales
- AC rental
- RO sales
- RO repair
- Spare-parts catalogue
- Reviews/testimonials
- Shop/location
- Book-service / callback
- WhatsApp + call CTAs
- Mobile sticky CTA
- Basic content/data management
- Analytics + Meta events
- SEO foundations
- LocalBusiness structured data
- 404/error states
- Production QA

## Non-goals for v1

Do not build unless explicitly requested:

- Customer accounts
- OTP login
- Full checkout
- Cart
- Payment gateway
- Order tracking
- Delivery management
- Technician workforce management
- Complex ERP/CRM
- Native Android/iOS apps

Build v2 features only after the lead funnel proves useful.
