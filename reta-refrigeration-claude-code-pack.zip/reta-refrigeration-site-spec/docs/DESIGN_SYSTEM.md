# Design System

## Design objective

The site should feel like:

**Trusted local shop + modern technology + fast service**

It should NOT feel like:
- a corporate consulting site
- a luxury brand
- a gaming site
- an overly futuristic portfolio

## 1. Visual direction

Recommended:
- white / near-white backgrounds
- deep navy/blue for structure
- cool blue/cyan accents
- dark gray text
- light gray borders
- modest shadows
- rounded but not excessive corners

## 2. Suggested semantic tokens

```text
--background
--surface
--surface-muted
--text
--text-muted
--primary
--primary-strong
--accent
--success
--warning
--danger
--border
```

Do not hardcode random colors across components.

## 3. Typography

Use a highly readable sans-serif.

Suggested:
- Inter
- Geist
- system UI fallback

Hierarchy:
- H1: strong and short
- H2: clear section titles
- H3: card titles
- body: readable 16px base on mobile
- labels: compact, high contrast

## 4. Buttons

Primary:
- WhatsApp
- Call
- Book Service
- Get Current Price

Secondary:
- View Products
- Get Directions
- View Reviews

Buttons should be:
- large enough for touch
- visually distinct
- short
- action-focused

## 5. Cards

Product/service cards:
- image
- title
- short attributes
- price/availability
- primary CTA

Do not overload cards with long descriptions.

## 6. Header

Desktop:
- logo
- 5–7 primary nav items
- prominent WhatsApp

Mobile:
- compact header
- menu
- WhatsApp visible where practical

## 7. Mobile sticky CTA

Persistent bottom action bar:

```text
[ Call Now ] [ WhatsApp ]
```

Use safe-area padding on supported devices.

Do not allow it to cover important content.

## 8. Hero

Must include:
- problem-oriented headline
- local relevance
- supporting line
- 2 main CTAs
- small practical trust indicators

Example pattern:

> AC / RO Problem? Need Repair or Spare Parts?

> Serving customers in approved local service areas.

> [WhatsApp Now] [Call Now]

## 9. Imagery

Priority:
1. real shop photos
2. real staff/technician photos
3. real inventory photos
4. product photography
5. stock imagery only when necessary

Avoid fake AI-generated customer photos as testimonials.

## 10. Icons

Use one consistent icon library.
Do not mix 4 different visual styles.

## 11. Animation

Use subtle:
- fade-in
- short slide
- hover lift
- button feedback

Avoid long scroll hijacking, parallax-heavy effects, autoplay video, or animation that delays the CTA.

## 12. Indian/local trust cues

Use:
- shop photo
- location
- landmark
- phone
- WhatsApp
- reviews
- availability
- service area
- business hours

Avoid fake badges such as:
- "No.1"
- "100% Guaranteed"
- "Best in India"
unless actually substantiated.

## 13. Accessibility

Target:
- keyboard navigation
- visible focus
- alt text
- sufficient color contrast
- semantic HTML
- clear form labels
- reduced motion support

## 14. Responsive breakpoints

Design from mobile upward.

Test:
- 360
- 375
- 390
- 412
- 768
- 1024
- 1366
- 1440+

## 15. Section spacing

Prefer generous but compact spacing:
- mobile: approximately 48–72px section spacing
- desktop: approximately 72–112px

Tune based on content density.

## 16. Homepage rhythm

Hero
→ quick action cards
→ service categories
→ sales/rental
→ spare parts
→ trust
→ testimonials
→ real shop photos
→ location
→ FAQ
→ final CTA
