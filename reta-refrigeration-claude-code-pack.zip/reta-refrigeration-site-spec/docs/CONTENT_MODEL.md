# Content Model and Content Rules

## 1. Business profile

```ts
type BusinessProfile = {
  name: string
  displayName: string
  descriptor: string
  phone: string
  whatsapp: string
  address: string
  landmark?: string
  mapUrl: string
  googleBusinessProfileUrl?: string
  hours: BusinessHour[]
  serviceAreas: ServiceArea[]
  socialLinks?: Record<string, string>
}
```

## 2. Service

```ts
type Service = {
  slug: string
  name: string
  category: "ac" | "ro" | "other"
  shortDescription: string
  description?: string
  startingPrice?: number
  priceType?: "fixed" | "starting_from" | "contact_for_price"
  serviceAreas?: string[]
  active: boolean
  featured: boolean
  image?: string
  whatsappMessage?: string
}
```

## 3. Product

```ts
type Product = {
  slug: string
  name: string
  category: "ac" | "ro" | "spare-part"
  subcategory?: string
  brand?: string
  model?: string
  description?: string
  price?: number
  priceType: "fixed" | "starting_from" | "contact_for_price"
  availability: "available" | "check_availability" | "unavailable"
  compatibility?: string[]
  image?: string
  featured: boolean
  active: boolean
}
```

## 4. Review/testimonial

```ts
type Testimonial = {
  quote: string
  customerName?: string
  source: "google" | "customer_testimonial"
  rating?: number
  verified?: boolean
  permissionGranted?: boolean
}
```

## 5. Lead

```ts
type Lead = {
  id: string
  createdAt: string
  name?: string
  phone: string
  location?: string
  service?: string
  product?: string
  message?: string
  source?: string
  medium?: string
  campaign?: string
  content?: string
  status: "new" | "contacted" | "quoted" | "scheduled" | "completed" | "cancelled" | "not_interested"
  notes?: string
}
```

## 6. Content language

Primary UI:
- simple English

Optional regional marketing/ad copy:
- Hindi/Hinglish

Do not mix languages randomly in navigation.

## 7. Copywriting rules

Use:
- direct
- practical
- local
- trustworthy
- short paragraphs
- visible pricing/availability when reliable
- clear CTAs

Avoid:
- exaggerated claims
- corporate fluff
- generic "world-class"
- fake superlatives
- unnecessary technical jargon

## 8. Reviews rule

Never invent reviews.

Store exact source and permission metadata for non-Google testimonials.

## 9. Price rule

Prices must be owner-approved and timestampable if practical.

Where prices fluctuate:
> Contact for current price

or:
> Starting from ...

## 10. Service-area rule

Never imply universal 50–70 km service coverage without owner confirmation.

Different services can have different zones.
