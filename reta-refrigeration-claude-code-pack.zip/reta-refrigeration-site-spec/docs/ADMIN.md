# Admin / CMS Requirements

## Admin goals

The owner should be able to manage basic business content without editing code.

## Dashboard

Show:
- new leads
- lead count by service
- recent enquiries
- active products
- low/out-of-stock products

Example:

```text
Today's Leads: 8

AC Repair: 4
RO Repair: 2
Spare Parts: 1
AC Rental: 1
```

## Product management

Admin can:
- add
- edit
- hide
- delete/soft-delete
- change price
- change availability
- upload image
- change category
- update compatibility

## Service management

Admin can:
- edit description
- mark active/inactive
- update service areas
- change pricing state
- update featured services

## Lead management

Lead statuses:
- new
- contacted
- quoted
- scheduled
- completed
- cancelled
- not_interested

Lead fields:
- name
- phone
- location
- service/product
- source/campaign
- notes
- created date

## Settings

Admin should eventually manage:
- phone
- WhatsApp number
- address
- hours
- map URL
- Google Business Profile URL
- service-area list

## Authentication

Use managed auth.
Do not store plaintext passwords.

## MVP option

If admin scope pushes budget/time too high:
- launch with static/seed data
- keep content typed and centralized
- add Supabase CRUD in v2

However, if spare-parts inventory changes frequently, basic admin CRUD is strongly recommended.
