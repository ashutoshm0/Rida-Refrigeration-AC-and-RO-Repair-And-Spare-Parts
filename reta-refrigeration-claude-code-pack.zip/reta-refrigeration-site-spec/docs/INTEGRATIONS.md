# Integrations

## 1. WhatsApp

Primary contact mechanism.

Use click-to-chat links with:
- correct business WhatsApp number
- URL-safe encoded prefilled message
- contextual intent

Examples:

### AC repair
`Hi, I need AC repair service. My AC problem is ____ and my location is ____.`

### Spare part
`Hi, I need this AC/RO spare part. I can share a photo/model number. Please confirm availability and price.`

### Rental
`Hi, I want to rent an AC. Please share available models, rental charges and terms.`

### AC purchase
`Hi, I want to buy an AC. Please share available models and current prices.`

### RO repair
`Hi, I need RO repair/service. My location is ____.`

Create a central helper:

```ts
buildWhatsAppUrl({
  phone,
  message,
  sourceContext
})
```

Do not scatter WhatsApp string-building logic across components.

## 2. Phone

Use:
`tel:+91...`

Create a central helper for normalized phone links.

## 3. Maps

Primary:
- Google Maps location URL
- Directions URL

Use the owner's exact business pin/address.

Do not invent coordinates.

## 4. Google Business Profile

Keep:
- business name
- address
- phone
- hours
- website
- photos
- service info

consistent with the official profile.

## 5. Analytics

Implement an abstraction:

```ts
track("whatsapp_click", {
  location: "hero",
  intent: "ac_repair",
})
```

Never hardcode provider-specific logic in every component.

## 6. Forms

Forms:
- callback
- service booking
- enquiry

Server-side validation required.

Recommended anti-spam:
- honeypot
- rate limiting
- optional CAPTCHA if abuse appears

## 7. Optional future integrations

Do not add without business need:
- CRM
- WhatsApp API automation
- payment gateway
- email automation
- inventory sync
