# Data Schema

Recommended Supabase tables.

## businesses

```sql
id uuid primary key
name text not null
display_name text not null
descriptor text
phone text
whatsapp text
address text
landmark text
map_url text
google_business_profile_url text
created_at timestamptz default now()
updated_at timestamptz default now()
```

## business_hours

```sql
id uuid primary key
business_id uuid references businesses(id)
day_of_week int not null
open_time time
close_time time
is_closed boolean default false
```

## service_areas

```sql
id uuid primary key
name text not null
zone_type text not null
notes text
service_available boolean default true
parts_sales_available boolean default true
```

`zone_type` examples:
- core
- regular
- extended
- enquiry_based

## services

```sql
id uuid primary key
slug text unique not null
name text not null
category text not null
short_description text
description text
price numeric
price_type text
active boolean default true
featured boolean default false
image_url text
created_at timestamptz default now()
updated_at timestamptz default now()
```

## products

```sql
id uuid primary key
slug text unique not null
name text not null
category text not null
subcategory text
brand text
model text
description text
price numeric
price_type text not null
availability text not null
active boolean default true
featured boolean default false
image_url text
created_at timestamptz default now()
updated_at timestamptz default now()
```

## product_compatibility

```sql
id uuid primary key
product_id uuid references products(id)
brand text
model text
notes text
```

## testimonials

```sql
id uuid primary key
quote text not null
customer_name text
source text not null
rating numeric
verified boolean default false
permission_granted boolean default false
active boolean default true
created_at timestamptz default now()
```

## leads

```sql
id uuid primary key
created_at timestamptz default now()
name text
phone text not null
location text
service text
product text
message text
source text
medium text
campaign text
content text
status text default 'new'
notes text
```

## admin users

Use Supabase Auth or another secure provider. Do not build custom password storage.

## Indexes

Consider indexes on:
- products.slug
- products.category
- products.availability
- products.active
- services.slug
- services.category
- leads.created_at
- leads.status

## Security

- Public: read active services/products.
- Public: create leads.
- Admin: authenticated CRUD.
- Never expose service role credentials client-side.
