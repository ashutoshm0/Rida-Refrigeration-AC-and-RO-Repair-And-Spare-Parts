# Application Architecture

## 1. Recommended stack

- Next.js (App Router)
- TypeScript
- Tailwind CSS
- Supabase for database/auth/storage if admin is included
- Vercel or equivalent deployment
- Optional form/CRM integration later

## 2. High-level architecture

```mermaid
flowchart TD
    A[Meta / Instagram Ads] --> B[Intent Landing Page]
    C[Google Search / Maps] --> D[Homepage or Local Landing Page]
    B --> E[WhatsApp]
    B --> F[Phone]
    B --> G[Booking / Callback]
    D --> E
    D --> F
    D --> G
    D --> H[Products / Spare Parts]
    H --> E
    G --> I[Lead Store]
    E --> J[Business WhatsApp]
    F --> K[Business Phone]
    I --> L[Admin Dashboard]
```

## 3. Suggested folder structure

```text
reta-refrigeration/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── not-found.tsx
│   ├── sitemap.ts
│   ├── robots.ts
│   ├── ac-repair-greater-noida/
│   │   └── page.tsx
│   ├── ac-sale-greater-noida/
│   │   └── page.tsx
│   ├── ac-rental-greater-noida/
│   │   └── page.tsx
│   ├── ro-repair-greater-noida/
│   │   └── page.tsx
│   ├── spare-parts/
│   │   ├── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx
│   ├── services/
│   │   ├── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx
│   ├── ac/
│   │   ├── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx
│   ├── ro/
│   │   ├── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx
│   ├── reviews/
│   │   └── page.tsx
│   ├── contact/
│   │   └── page.tsx
│   ├── book-service/
│   │   └── page.tsx
│   └── admin/
│       ├── page.tsx
│       ├── products/
│       ├── services/
│       ├── leads/
│       └── settings/
│
├── components/
│   ├── layout/
│   ├── navigation/
│   ├── hero/
│   ├── sections/
│   ├── cards/
│   ├── forms/
│   ├── cta/
│   ├── product/
│   ├── reviews/
│   ├── location/
│   └── analytics/
│
├── lib/
│   ├── whatsapp.ts
│   ├── phone.ts
│   ├── analytics.ts
│   ├── meta.ts
│   ├── maps.ts
│   ├── validation.ts
│   ├── seo.ts
│   └── db.ts
│
├── types/
│   ├── business.ts
│   ├── service.ts
│   ├── product.ts
│   ├── lead.ts
│   └── review.ts
│
├── content/
│   ├── business.ts
│   ├── services.ts
│   ├── faqs.ts
│   └── landing-pages.ts
│
├── public/
│   ├── brand/
│   ├── shop/
│   ├── products/
│   └── icons/
│
├── config/
│   ├── site.ts
│   └── tracking.ts
│
└── docs/
```

## 4. Component philosophy

Use reusable components, but do not over-abstract.

Good:
- `WhatsAppButton`
- `CallButton`
- `ProductCard`
- `ServiceCard`
- `ReviewCard`
- `LocationBlock`
- `StickyMobileCta`
- `EnquiryForm`

Avoid building an over-generic design framework for a single local business.

## 5. Server/client split

Prefer server components for:
- content
- product listings
- SEO
- static sections

Use client components for:
- filters
- interactive forms
- sticky CTA behavior
- dynamic admin UI
- analytics hooks where needed

## 6. Data source

Business data should be externalized from UI code.

The application should be able to run with:
- static seed data in v1
- Supabase-backed data in v1/v2

The UI should not need rewriting when prices/products change.

## 7. Security

- Validate all form input server-side.
- Add basic rate limiting / anti-spam.
- Never expose Supabase service-role key to the browser.
- Keep private configuration in environment variables.
- Do not log sensitive customer information unnecessarily.
