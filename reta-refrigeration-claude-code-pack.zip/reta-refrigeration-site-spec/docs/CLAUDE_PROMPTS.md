# Useful Claude Code Prompts

## Prompt 1 — Bootstrap

Read:
- `CLAUDE_CODE_HANDOFF.md`
- `docs/PROJECT_SPEC.md`
- `docs/ARCHITECTURE.md`
- `docs/DESIGN_SYSTEM.md`

Bootstrap the Next.js TypeScript project and create the initial folder structure. Do not invent business data. Use clearly marked placeholders.

## Prompt 2 — Build homepage

Read:
- `docs/PROJECT_SPEC.md`
- `docs/DESIGN_SYSTEM.md`
- `docs/ROUTES.md`
- `docs/CONTENT_MODEL.md`

Build the homepage mobile-first with a strong local Indian service-business UX. Prioritize WhatsApp and phone conversion over decorative content.

## Prompt 3 — Build spare-parts catalogue

Read:
- `docs/CONTENT_MODEL.md`
- `docs/DATA_SCHEMA.md`
- `docs/DESIGN_SYSTEM.md`

Build searchable/category-filtered spare-parts browsing with price/availability states and photo-enquiry fallback.

## Prompt 4 — Build analytics layer

Read:
- `docs/META_TRACKING.md`
- `docs/INTEGRATIONS.md`

Implement a reusable analytics/event layer and wire all conversion actions.

## Prompt 5 — Run QA

Read:
- `docs/QA_CHECKLIST.md`

Audit the entire app against the checklist. Fix issues instead of merely reporting them. Do not invent missing business data.
