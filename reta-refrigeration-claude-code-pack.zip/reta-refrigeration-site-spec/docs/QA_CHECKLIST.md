# QA and Launch Checklist

## Business data

- [ ] Business name verified
- [ ] Exact address verified
- [ ] Phone verified
- [ ] WhatsApp verified
- [ ] Map pin verified
- [ ] Google Business Profile verified
- [ ] Hours verified
- [ ] Service areas approved

## Content

- [ ] No lorem ipsum
- [ ] No fake reviews
- [ ] No invented claims
- [ ] No invented pricing
- [ ] No unsupported service areas
- [ ] Real shop photos included
- [ ] Product images match products
- [ ] Availability states work
- [ ] Price states work

## UX

- [ ] WhatsApp above the fold on mobile
- [ ] Call above the fold on mobile
- [ ] Sticky mobile CTA works
- [ ] No long mandatory forms
- [ ] Navigation works
- [ ] Product search works
- [ ] Spare-parts enquiry fallback works
- [ ] Directions works
- [ ] Booking works
- [ ] Callback works

## Tracking

- [ ] page_view
- [ ] whatsapp_click
- [ ] phone_click
- [ ] callback_submit
- [ ] booking_submit
- [ ] product_enquiry
- [ ] spare_part_enquiry
- [ ] rental_enquiry
- [ ] get_directions
- [ ] UTM captured where needed

## SEO

- [ ] title tags
- [ ] meta descriptions
- [ ] canonical URLs
- [ ] sitemap
- [ ] robots.txt
- [ ] OG metadata
- [ ] favicon
- [ ] structured data
- [ ] alt text
- [ ] Search Console ready

## Technical

- [ ] production build succeeds
- [ ] no major console errors
- [ ] no broken links
- [ ] no broken images
- [ ] HTTPS enabled
- [ ] env vars documented
- [ ] no secrets in repo
- [ ] 404 page works

## Responsive

- [ ] 360px
- [ ] 375px
- [ ] 390px
- [ ] 412px
- [ ] 768px
- [ ] 1024px
- [ ] 1366px
- [ ] 1440px+

## Performance

- [ ] images optimized
- [ ] lazy-loading where appropriate
- [ ] fonts optimized
- [ ] JS minimized
- [ ] no unnecessary heavy libraries
- [ ] mobile performance reviewed

## Client handover

- [ ] domain ownership confirmed
- [ ] hosting ownership/access confirmed
- [ ] Google Business Profile access confirmed
- [ ] Meta Business access confirmed
- [ ] analytics access confirmed
- [ ] source code handed over
- [ ] content update instructions provided
