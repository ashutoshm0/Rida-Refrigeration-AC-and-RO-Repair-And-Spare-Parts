# Project Specification

## 1. Product definition

Reta Refrigeration's website is a **local lead-generation platform and digital shop catalogue**.

It serves two major jobs:

### Service intent
- AC repair
- AC servicing
- AC installation
- AC maintenance
- AC cleaning
- AC gas-related services where actually offered
- RO repair
- RO installation
- RO maintenance
- other owner-approved services

### Product intent
- AC for sale
- AC for rent
- AC spare parts
- RO for sale
- RO spare parts
- accessories

## 2. Primary personas

### Persona A — urgent service customer
Typical thought:
> "AC isn't cooling. I need someone nearby."

Desired path:
Ad/Search → service page → WhatsApp/Call

### Persona B — product buyer
Typical thought:
> "Need an AC / RO. What models and prices are available?"

Desired path:
Search/Ad → product catalogue → price/availability → WhatsApp/Call

### Persona C — spare-parts buyer
Typical thought:
> "I need this part. Is it available and what is the price?"

Desired path:
Search/Ad → spare-parts catalogue → part page → WhatsApp with part context

### Persona D — rental customer
Typical thought:
> "Need an AC on rent for a specific duration."

Desired path:
Ad → rental page → availability enquiry → WhatsApp

### Persona E — nearby store visitor
Typical thought:
> "Is this a genuine shop and where is it?"

Desired path:
Search/Maps → website → photos/reviews/location → directions/call

## 3. Conversion hierarchy

1. WhatsApp
2. Phone call
3. Callback request
4. Service booking
5. Product/spare-parts enquiry
6. Directions/store visit

## 4. Trust hierarchy

Use the following, in roughly this order:

1. Real business identity
2. Real shop photos
3. Accurate location
4. Genuine reviews/testimonials
5. Clear services
6. Availability/price transparency
7. Simple contact path
8. Business hours
9. Service-area clarity
10. Policies

## 5. Homepage requirements

The homepage must contain:

- Hero
- Primary CTAs
- Quick services
- AC services
- RO services
- AC sales preview
- AC rental preview
- Spare-parts preview
- Why choose / practical trust signals
- Reviews/testimonials
- Real shop photos
- Location/map/directions
- FAQ
- Final CTA
- Footer

## 6. Contextual CTAs

Use:
- "WhatsApp for AC Repair"
- "Check AC Availability"
- "Ask Current Price"
- "Check Spare Part Availability"
- "Ask Rental Availability"
- "Book RO Repair"
- "Get Directions"
- "Call Now"

Avoid overusing:
- "Learn More"
- "Submit"
- "Contact Us" as the only CTA

## 7. Indian/local UX requirements

- Very low friction
- Minimal forms
- No login
- No forced email
- Clear phone number
- WhatsApp everywhere it matters
- Simple English for UI
- Hindi/Hinglish can be used in selected ad/CTA copy
- Show practical information before long marketing copy
- Real shop photos are preferred
- Product price can be "current price on WhatsApp" where inventory changes
- Availability is a first-class property
- Customers may not know exact technical part names → provide photo-enquiry route

## 8. Service radius model

Do not assume every service is offered equally far away.

Model service zones:
- Core
- Regular
- Extended
- Enquiry-based

The actual boundaries are owner-provided.

Parts/product sales may have a wider market than technician visits.

## 9. Spare-parts special feature

Add:
> Don't know the part name? Send us a photo on WhatsApp.

This should be visible on the parts catalogue and empty-search state.

## 10. Price states

Supported UI states:
- fixed
- starting_from
- contact_for_price
- unavailable
- check_availability

## 11. Ads landing-page rules

Every high-value ad intent should have a dedicated landing page.

A landing page should have:
- problem statement
- service scope
- local relevance
- CTA above fold
- trust
- process
- FAQs
- reviews/testimonials
- location/service areas
- repeat CTA

Do not distract the user with unrelated content.

## 12. Non-functional requirements

- Responsive
- Accessible
- Fast
- SEO-ready
- Secure form handling
- Spam-resistant forms
- Analytics-ready
- Easy content updates
- Production logging
- Error states
