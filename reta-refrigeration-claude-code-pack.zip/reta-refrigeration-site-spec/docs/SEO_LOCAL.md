# Local SEO + Google Business Profile Plan

## Objective

Capture local-intent search traffic around:
- AC repair
- AC service
- AC spare parts
- AC rental
- AC sales
- RO repair
- RO sales
- RO spare parts

## Local keyword themes

Examples:
- AC repair Sector 149
- AC repair Greater Noida
- AC service Greater Noida
- AC spare parts Greater Noida
- AC on rent Greater Noida
- RO repair Sector 149
- RO repair Greater Noida
- RO spare parts Greater Noida
- AC shop near me (covered naturally, not by keyword stuffing)

Use only accurate area/service combinations.

## Technical SEO

Implement:
- unique titles
- unique meta descriptions
- canonical URLs
- sitemap
- robots.txt
- Open Graph metadata
- favicon
- clean URLs
- proper heading hierarchy
- image alt text
- LocalBusiness / Organization structured data
- BreadcrumbList where beneficial

## LocalBusiness data

Include only verified:
- name
- address
- phone
- URL
- opening hours
- logo
- location
- relevant business category/type

Do not invent:
- rating
- review count
- geo coordinates
- service areas
- price range

## Google Business Profile alignment

The website and profile should agree on:
- business name
- location
- phone
- hours
- website

Encourage the owner to maintain:
- real shop photos
- real product/service photos
- genuine reviews
- current hours
- accurate business category
- current website

## Review policy

Use genuine customer reviews/testimonials only.

Never create fake Google reviews.

## Location page

Must contain:
- exact address
- map
- directions
- landmarks if accurate
- phone
- hours
- service-area information

## On-page local structure

H1:
> AC & RO Repair, Sales, Rental & Spare Parts in [Approved Primary Area]

Then naturally mention:
- primary locality
- Greater Noida
- relevant nearby approved areas

Avoid repeating the same locality unnaturally.

## Search Console

After deployment:
- verify the domain
- submit sitemap
- inspect core pages
- monitor indexing
- monitor search queries and CTR

## SEO expectation

SEO improvements compound over time.
Do not promise guaranteed rankings.
