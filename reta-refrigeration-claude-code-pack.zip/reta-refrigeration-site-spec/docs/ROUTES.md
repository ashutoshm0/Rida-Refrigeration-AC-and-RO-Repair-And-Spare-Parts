# Routes and Page Requirements

## Core routes

| Route | Purpose | Primary CTA |
|---|---|---|
| `/` | Main business overview | WhatsApp |
| `/services` | Service directory | Book / WhatsApp |
| `/services/[slug]` | Individual service | WhatsApp |
| `/ac-repair-greater-noida` | Meta/SEO AC repair landing page | WhatsApp |
| `/ac-sale-greater-noida` | AC purchase landing page | Get Price |
| `/ac-rental-greater-noida` | AC rental landing page | Check Availability |
| `/ro-repair-greater-noida` | RO repair landing page | WhatsApp |
| `/spare-parts` | Spare parts catalogue | Ask Availability |
| `/spare-parts/[slug]` | Individual part | Ask Price |
| `/ac` | AC category | Browse |
| `/ac/[slug]` | AC product/detail | Get Price |
| `/ro` | RO category | Browse |
| `/ro/[slug]` | RO product/detail | Get Price |
| `/reviews` | Reviews/testimonials | Call/WhatsApp |
| `/contact` | Contact/location | Directions |
| `/book-service` | Booking/callback | Submit/WhatsApp |
| `/admin` | Admin dashboard | Manage |

## Homepage sections

1. Header
2. Hero
3. Quick action grid
4. AC services
5. RO services
6. AC sales preview
7. AC rental preview
8. Spare parts preview
9. Trust signals
10. Reviews
11. Shop photos
12. Location
13. FAQ
14. Final CTA
15. Footer

## Intent landing page template

```text
Hero
↓
Problem / intent statement
↓
Primary CTA
↓
Service/product coverage
↓
Why contact us
↓
How it works
↓
Areas served
↓
Reviews/testimonials
↓
FAQ
↓
Location
↓
Final CTA
```

## Empty states

### Spare parts search
> Can't find the part?

CTA:
**Send a photo on WhatsApp**

### Product unavailable
> Currently unavailable

CTA:
**Ask for an alternative**

### Outside service area
> Service availability depends on location.

CTA:
**WhatsApp to confirm availability**

## 404

Include:
- clear message
- Home
- Services
- Spare Parts
- WhatsApp
