# Owner Inputs Required Before Launch

This file is the handoff questionnaire. Replace every placeholder with verified owner information.

## Identity
- [ ] Exact legal/consumer-facing business name
- [ ] Preferred website display name
- [ ] Logo

## Contact
- [ ] Phone
- [ ] WhatsApp
- [ ] Backup contact if any

## Location
- [ ] Exact shop address
- [ ] Landmark
- [ ] Google Maps URL
- [ ] Google Business Profile URL

## Hours
- [ ] Monday
- [ ] Tuesday
- [ ] Wednesday
- [ ] Thursday
- [ ] Friday
- [ ] Saturday
- [ ] Sunday
- [ ] Holiday policy

## AC services
- [ ] Repair
- [ ] Service
- [ ] Installation
- [ ] Cleaning
- [ ] Gas-related services
- [ ] Maintenance
- [ ] Other

## RO services
- [ ] Repair
- [ ] Installation
- [ ] Filter replacement
- [ ] Maintenance
- [ ] Other

## Sales
- [ ] AC brands/models
- [ ] RO brands/models
- [ ] New/used/refurbished status
- [ ] Sales pricing
- [ ] Warranty terms

## Rental
- [ ] Available AC capacities
- [ ] Rental duration options
- [ ] Rental price
- [ ] Deposit
- [ ] Delivery/setup terms
- [ ] Service area
- [ ] Availability status

## Spare parts
- [ ] AC part catalogue
- [ ] RO part catalogue
- [ ] Prices
- [ ] Brands
- [ ] Compatibility
- [ ] Availability
- [ ] Photos

## Service area
- [ ] Core areas
- [ ] Regular areas
- [ ] Extended areas
- [ ] Enquiry-based areas
- [ ] Visit/service charge rules

## Trust
- [ ] Real testimonials
- [ ] Google review link
- [ ] Review screenshots only if needed
- [ ] Shop photos
- [ ] Team/technician photos

## Policies
- [ ] Service/inspection charges
- [ ] Warranty
- [ ] Replacement/return
- [ ] Rental terms
- [ ] Privacy/data-use information

## Advertising
- [ ] Meta Business account access
- [ ] Pixel ID
- [ ] Page/Instagram account
- [ ] Ad account
- [ ] Campaign naming plan
- [ ] Approved landing-page offers

## Ownership
- [ ] Domain account
- [ ] Hosting account
- [ ] Google Business Profile
- [ ] Meta Business Manager
- [ ] Analytics / Search Console
