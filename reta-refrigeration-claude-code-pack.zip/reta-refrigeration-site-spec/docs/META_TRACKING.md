# Meta Ads + Tracking Specification

## Goal

Measure actions that matter to the business.

## Core events

### `page_view`
Standard page view.

### `whatsapp_click`

Properties:
- `intent`
- `location`
- `page`
- `source`
- `campaign`
- `content`

### `phone_click`

Properties:
- `location`
- `page`
- `intent`

### `callback_submit`

Properties:
- `service`
- `page`
- UTM context

### `booking_submit`

Properties:
- `service`
- `page`
- UTM context

### `product_enquiry`

Properties:
- `product_id`
- `product_name`
- `category`

### `spare_part_enquiry`

Properties:
- `part_id` if known
- `part_name` if known

### `rental_enquiry`

Properties:
- `product`
- `capacity` if available

### `get_directions`

Properties:
- `page`
- `location`

## UTM fields

Capture:

```text
utm_source
utm_medium
utm_campaign
utm_term
utm_content
```

Persist attribution to lead submission when practical.

## Campaign-to-page mapping

| Campaign intent | Landing page |
|---|---|
| AC repair | `/ac-repair-greater-noida` |
| RO repair | `/ro-repair-greater-noida` |
| AC rental | `/ac-rental-greater-noida` |
| AC sale | `/ac-sale-greater-noida` |
| Spare parts | `/spare-parts` |

Use approved locality wording.

## Funnel metrics

Primary:
- qualified WhatsApp conversations
- qualified calls
- booked jobs
- completed jobs
- cost per qualified lead

Secondary:
- landing page sessions
- WhatsApp CTR
- phone CTR
- form completion rate
- directions clicks

Do not treat raw page views as the primary business KPI.

## Important implementation rule

Track click events on:
- hero CTA
- navigation CTA
- service card CTA
- product card CTA
- floating CTA
- final CTA

But avoid counting the same click multiple times due to duplicate event handlers.
