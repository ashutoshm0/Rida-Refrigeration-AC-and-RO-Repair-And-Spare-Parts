# Asset Requirements

Before launch, collect the client's actual assets.

## Required brand assets

- Logo (SVG preferred)
- Favicon
- Business board/sign photo

## Shop photos

- exterior
- entrance
- interior/counter
- spare-parts shelves
- AC units
- RO units
- technician/service work

## Product images

Prefer:
- real inventory photos
- consistent aspect ratio
- clear background
- compressed WebP/AVIF

## Review proof

Collect:
- real Google Business Profile review link
- screenshots only if legally/permission-safe and necessary
- customer testimonials with permission

## Image naming

Use descriptive names:
`reta-ac-spare-part-capacitor-35-5.jpg`
not:
`IMG_2388.jpg`

## Alt text

Describe the image accurately.
Do not keyword-stuff.
